package miniJava.SyntacticAnalyzer;

public class SourcePosition {

}
