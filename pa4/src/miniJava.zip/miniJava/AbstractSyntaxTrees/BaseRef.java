package miniJava.AbstractSyntaxTrees;

import miniJava.SyntacticAnalyzer.SourcePosition;

public abstract class BaseRef extends Reference {

	public BaseRef(SourcePosition posn){
		super(posn);
	}
}
